package com.perscholas.java_basics;

public class VariablesExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//	1. 	Declaration
		int A;
		int B;
		int sum;

//		Assignment
		A = 1;
		B = 2;
		sum = (A + B);
		System.out.println(sum);

//	2.  Initialization is declaration and assignment combined i.e
		double C = 1.5;
		double D = 2.3;
		double sum2 = (C + D);
		System.out.println(sum2);

// 3.	the sum must be a double b/c the result will be a decimal
		int E = 3;
		double F = 2.6;
		double sum3 = (E + F);
		System.out.println(sum3);

// 4.	"Type mismatch: cannot convert from double to int". Variable G and sum 4 need
//		to be changed to doubles. i.e double G = 8, double sum4.
//		int G = 8.5;
//		int H = 4;
//		int sum4 = (G / H);
//		System.out.println(sum4);
//		
		double G = 8.5;
		int H = 4;
		double sum4 = (G / H);
		System.out.println(sum4);

// 5.	
		double I = 7.2;
		double J = 5.1;
		double sum5 = (I / J);
		System.out.println(sum5);

// 6.	
		int X = 5;
		int Y = 6;
//		int Q = (Y / X);
		double Z = Y;
		double Q = (Z / X);
		System.out.println(Q);
		
// 7.
		final double WaterBottle = 1.65;
		int Customers = 25;
		double Sold = (WaterBottle * Customers);
		
		System.out.println(Sold);
		
// 8.
		double Americano = 3.25;
		double Latte = 2.30;
		double Espresso = 2.65;
		final double SALES_TAX = 0.065; 
		
		
		double Subtotal = (Americano * 3 + Latte * 4 + Espresso * 2);
		double TotalSale = (Subtotal * SALES_TAX + Subtotal); 
		System.out.println(TotalSale);
		
		

	}

}
